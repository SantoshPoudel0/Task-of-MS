
# font-family: Impact, serif;
# background-color: burlywood
# divider-color: brown

### heading font-size: 40px;
#### sub font-size: 30px;
